<?php get_header(); ?>

<div class="container text-center">

        <?php if(have_posts()) :  ?>  
            <?php while(have_posts()) : the_post(); ?>

          <div class="blog-post">
          <a><h2 class="blog-post-title">
           
             <?php the_title(); ?> </h2></a>
            <p class="blog-post-meta"><?php the_time('F j, Y g:i a'); ?>
            <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p>

            <?php the_content(); ?>
            <?php comments_template(); ?> 
              

          <?php endwhile; ?> 
            <?php else : ?> 
              <p><?php__('No Posts Found'); ?></p>
          <?php endif; ?>
          </div>
</div>

<?php get_footer(); ?>